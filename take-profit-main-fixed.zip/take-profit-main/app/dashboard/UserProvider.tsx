"use client";

import {
  createContext,
  useContext,
  useEffect,
  useState,
} from "react";

type User = {
  first_name: string;
  last_name: string;
  email: string;
  country: string;
  referral_code: string;
  referral_count: number;
  email_verified: boolean;
  created_at: string;
  is_admin: boolean;
};

const UserContext = createContext<{
  user: User | null;
  loading: boolean;
}>({
  user: null,
  loading: true,
});

export function UserProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function loadUser() {
      try {
        // Auth now runs off the httpOnly session cookie set at
        // verification time, the browser sends it automatically on
        // this same-origin request, nothing to read from localStorage.
        const response = await fetch("/api/dashboard");

        if (!response.ok) {
          setLoading(false);
          return;
        }

        const data = await response.json();

        setUser(data);
      } catch (err) {
        console.error(err);
      } finally {
        setLoading(false);
      }
    }

    loadUser();
  }, []);

  return (
    <UserContext.Provider
      value={{
        user,
        loading,
      }}
    >
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  return useContext(UserContext);
}
