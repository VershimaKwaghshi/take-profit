import { NextResponse } from "next/server";
import { verifySessionToken } from "./session";

export const SESSION_COOKIE_NAME = "tp_session";

/**
 * Reads and verifies the session cookie directly from the request headers.
 * Works the same for a plain Request or a NextRequest, so it's safe to use
 * in every route handler regardless of whether params are involved.
 */
export function getSessionFromRequest(request: Request) {
  const cookieHeader = request.headers.get("cookie") || "";

  const match = cookieHeader
    .split(";")
    .map((c) => c.trim())
    .find((c) => c.startsWith(`${SESSION_COOKIE_NAME}=`));

  if (!match) return null;

  const raw = match.slice(SESSION_COOKIE_NAME.length + 1);

  let token: string;
  try {
    token = decodeURIComponent(raw);
  } catch {
    token = raw;
  }

  return verifySessionToken(token);
}

/**
 * Use at the top of any authenticated route. Returns a 401 response if
 * there's no valid session so the caller can just `return` it.
 */
export function requireSession(request: Request) {
  const session = getSessionFromRequest(request);

  if (!session) {
    return {
      session: null,
      response: NextResponse.json(
        { error: "Not authenticated." },
        { status: 401 }
      ),
    };
  }

  return { session, response: null as NextResponse | null };
}

/**
 * Use at the top of any admin-only route. Returns 401 if not logged in,
 * 403 if logged in but not an admin.
 */
export function requireAdmin(request: Request) {
  const session = getSessionFromRequest(request);

  if (!session) {
    return {
      session: null,
      response: NextResponse.json(
        { error: "Not authenticated." },
        { status: 401 }
      ),
    };
  }

  if (!session.is_admin) {
    return {
      session: null,
      response: NextResponse.json(
        { error: "Forbidden." },
        { status: 403 }
      ),
    };
  }

  return { session, response: null as NextResponse | null };
}
